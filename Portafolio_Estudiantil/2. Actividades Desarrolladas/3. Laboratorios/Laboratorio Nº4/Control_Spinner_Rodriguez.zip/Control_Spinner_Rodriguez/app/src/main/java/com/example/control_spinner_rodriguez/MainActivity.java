package com.example.control_spinner_rodriguez;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText Username,Password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Username = findViewById(R.id.Username);
        Password = findViewById(R.id.Password);
    }
    public void validate(View v) {
        String password = Password.getText().toString();
        if (password.isEmpty()) {

            Toast.makeText(MainActivity.this, "Por favor ingrese una contraseña", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(MainActivity.this, "Acceso correcto", Toast.LENGTH_LONG).show();
        }
    }
}