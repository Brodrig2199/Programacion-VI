package com.example.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Checkbutton extends AppCompatActivity {
    private EditText Num1, Num2;
    private TextView txtResultado;
    private CheckBox Cb1, Cb2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkbutton);
        Num1 = findViewById(R.id.Num1);
        Num2 = findViewById(R.id.Num2);
        txtResultado = findViewById(R.id.txtResultado);
        Cb1 = findViewById(R.id.Cb1);
        Cb2 = findViewById(R.id.Cb2);
    }
    public void Operar(View view) {
        String v1 = Num1.getText().toString();
        String v2 = Num2.getText().toString();

        int n1 = Integer.parseInt(v1);
        int n2 = Integer.parseInt(v2);

        if (Cb1.isChecked() == true) {
            int suma = n1 + n2;
            String r = String.valueOf(suma);
            txtResultado.setText(r);
        }
        if (Cb2.isChecked() == true) {
            int resta = n1 - n2;
            String r = String.valueOf(resta);
            txtResultado.setText(r);
        }
        if (Cb1.isChecked() == true && Cb2.isChecked() == true) {
            String r = String.valueOf("ERROR");
            txtResultado.setText(r);
            Toast.makeText(this, "Debe seleccionar una opcion", Toast.LENGTH_LONG).show();

        }
    }
    public void Salir(View view){
        finish();
    }
}