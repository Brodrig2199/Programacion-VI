package com.example.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void Spin(View view){
        Intent i = new Intent(this,Spin.class);
        startActivity(i);
    }
    public void Checkbutton(View view){
        Intent i = new Intent(this,Checkbutton.class);
        startActivity(i);
    }
    public void ImgButton(View view){
        Intent i = new Intent(this,ImgButton.class);
        startActivity(i);
    }
    public void RadioButton(View view){
        Intent i = new Intent(this,RadioButton.class);
        startActivity(i);
    }

    public void Switch(View view){
        Intent i = new Intent(this,Switch.class);
        startActivity(i);
    }
    public void Salir(View view){
        finish();
    }
}