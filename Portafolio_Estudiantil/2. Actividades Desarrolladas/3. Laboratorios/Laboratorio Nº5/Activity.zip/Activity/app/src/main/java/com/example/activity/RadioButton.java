package com.example.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class RadioButton extends AppCompatActivity {

    private EditText Num1,Num2;
    private TextView txtResultado;
    private android.widget.RadioButton Rb1,Rb2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radio_button);

        Num1 = findViewById(R.id.Num1);
        Num2 = findViewById(R.id.Num2);
        txtResultado = findViewById(R.id.txtResultado);
        Rb1 = findViewById(R.id.Rb1);
        Rb2 = findViewById(R.id.Rb2);
    }

    public void Operar (View view){
        String v1= Num1.getText().toString();
        String v2= Num2.getText().toString();

        int n1= Integer.parseInt(v1);
        int n2= Integer.parseInt(v2);

        if(Rb1.isChecked()== true){
            int suma = n1 + n2;
            String r = String.valueOf(suma);
            txtResultado.setText(r);
        }
        else if (Rb2.isChecked()== true){
            int resta = n1 - n2;
            String r = String.valueOf(resta);
            txtResultado.setText(r);
        }

    }
    public void Salir(View view){
        finish();
    }
}