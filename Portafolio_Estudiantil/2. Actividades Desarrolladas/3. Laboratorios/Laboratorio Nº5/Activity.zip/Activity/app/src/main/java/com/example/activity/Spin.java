package com.example.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class Spin extends AppCompatActivity {

    private TextView tv;
    private EditText N1,N2;
    private Spinner spin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spin);

        N1 = findViewById(R.id.N1);
        N2 = findViewById(R.id.N2);
        tv = findViewById(R.id.tv);
        spin = findViewById(R.id.spin);
        String[] opciones = {"sumar", "restar", "dividir", "multiplicar"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,opciones);

        spin.setAdapter(adapter);
    }
    public void resultado (View v) {
        String num1 = N1.getText().toString();
        String num2 = N2.getText().toString();
        double v1 = Double.parseDouble(num1);
        double v2 = Double.parseDouble(num2);

        String selec = spin.getSelectedItem().toString();
        if (selec.equals("sumar")) {
            double suma = v1 + v2;
            String r = String.valueOf(suma);
            tv.setText(r);
        } else if (selec.equals("resta")) {
            double resta = v1 - v2;
            String r = String.valueOf(resta);
            tv.setText(r);

        } else if (selec.equals("multiplicar")) {
            double multiplicar = v1 * v2;
            String r = String.valueOf(multiplicar);
            tv.setText(r);
        } else if (selec.equals("dividir")) {
            double dividir = v1 / v2;
            String r = String.valueOf(dividir);
            tv.setText(r);
        }
    }
    public void Salir(View view){
        finish();
    }


}