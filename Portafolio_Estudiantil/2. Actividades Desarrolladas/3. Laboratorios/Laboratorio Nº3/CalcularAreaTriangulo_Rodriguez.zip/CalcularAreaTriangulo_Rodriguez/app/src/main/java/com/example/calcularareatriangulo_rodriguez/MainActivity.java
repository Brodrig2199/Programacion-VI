package com.example.calcularareatriangulo_rodriguez;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText Num1, Num2, Num3;
    private TextView txtResultado;
    private CheckBox Cb1, Cb2 ,Cb3;
    private RadioButton Rb1,Rb2,Rb3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Num1 = findViewById(R.id.Num1);
        Num2 = findViewById(R.id.Num2);
        Num3 = findViewById(R.id.Num3);
        txtResultado = findViewById(R.id.txtResultado);
        Rb1 = findViewById(R.id.rb1);
        Rb2 = findViewById(R.id.rb2);
        Rb3 = findViewById(R.id.rb3);
        Cb1 = findViewById(R.id.Cb1);
        Cb2 = findViewById(R.id.Cb2);
        Cb3 = findViewById(R.id.Cb3);
    }
    public void Calcular(View view) {
        String v1 = Num1.getText().toString();
        String v2 = Num2.getText().toString();
        String v3 = Num3.getText().toString();

        int n1 = Integer.parseInt(v1);
        int n2 = Integer.parseInt(v2);
        int n3 = Integer.parseInt(v3);
        //Si es triangulo equilatero
        if (Rb1.isChecked() == true) {
            if(Cb1.isChecked()==true) {
                double area = (Math.sqrt(3) / 4) * Math.pow(n1, 2);
                String r = String.valueOf(area);
                txtResultado.setText(r);
            }
            if(Cb2.isChecked()==true) {
                double area = (Math.sqrt(3) / 4) * Math.pow(n2, 2);
                String r = String.valueOf(area);
                txtResultado.setText(r);
            }
            if(Cb3.isChecked()==true) {
                double area = (Math.sqrt(3) / 4) * Math.pow(n3, 2);
                String r = String.valueOf(area);
                txtResultado.setText(r);
            }
            if(Cb1.isChecked()==true) {
                double area = (Math.sqrt(3) / 4) * Math.pow(n1, 2);
                String r = String.valueOf(area);
                txtResultado.setText(r);
            }
            if(Cb1.isChecked()==true && Cb2.isChecked()==true ||Cb1.isChecked()==true && Cb3.isChecked()==true ||Cb2.isChecked()==true && Cb3.isChecked()==true||Cb1.isChecked()==true && Cb2.isChecked()==true && Cb3.isChecked()==true ) {
                String r = String.valueOf("ERROR");
                txtResultado.setText(r);
                Toast.makeText(this, "Debe seleccionar una opcion ya que es un triangulo equilatero", Toast.LENGTH_LONG).show();
            }
        }
        //Si es triangulo isoceles
        if (Rb2.isChecked() == true) {
            if(Cb1.isChecked()==true && Cb2.isChecked()==true) {
                double area = (n2 * Math.sqrt(Math.pow(n1, 2) - Math.pow(n2 / 2, 2))) / 2;
                String r = String.valueOf(area);
                txtResultado.setText(r);
            }
            if(Cb1.isChecked()==true && Cb3.isChecked()==true) {
                double area = (n3 * Math.sqrt(Math.pow(n1, 2) - Math.pow(n3 / 2, 2))) / 2;
                String r = String.valueOf(area);
                txtResultado.setText(r);
            }
            if(Cb2.isChecked()==true && Cb3.isChecked()==true) {
                double area = (n3 * Math.sqrt(Math.pow(n2, 2) - Math.pow(n3 / 2, 2))) / 2;
                String r = String.valueOf(area);
                txtResultado.setText(r);
            }
            if(Cb1.isChecked()==true && Cb2.isChecked()==true && Cb3.isChecked()==true) {
                String r = String.valueOf("ERROR");
                txtResultado.setText(r);
                Toast.makeText(this, "Debe seleccionar dos opciones ya que es un triangulo isoceles", Toast.LENGTH_LONG).show();
            }

        }
        //Si es triangulo escaleno
        if (Rb3.isChecked() == true) {
            if(Cb1.isChecked()==true && Cb2.isChecked()==true && Cb3.isChecked()==true) {
                double p = (n1 + n2 + n3) / 2;
                double area = Math.sqrt(p * (p - n1) * (p - n2) * (p - n3));
                String r = String.valueOf(area);
                txtResultado.setText(r);

            }

        }
    }
}