package com.example.list_view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    ListView lvM;
    String[] months = {"January", "February"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lvM = findViewById(R.id.lvM);

        ArrayAdapter<String> monthAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, months);

        lvM.setAdapter(monthAdapter);

        lvM.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String month = months[position];
        Toast.makeText(getApplicationContext(), "Clicked: " + month, Toast.LENGTH_SHORT).show();

        Opciones(month);
    }

    private void Opciones(String month) {
        switch (month) {
            case "January":
                January();
                break;
            case "February":
                February();
                break;
            default:
                Toast.makeText(getApplicationContext(), "Choose between January and February", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    public void January() {
        Intent i = new Intent(this, January.class);
        startActivity(i);
    }

    public void February() {
        Intent i = new Intent(this, February.class);
        startActivity(i);
    }
}
