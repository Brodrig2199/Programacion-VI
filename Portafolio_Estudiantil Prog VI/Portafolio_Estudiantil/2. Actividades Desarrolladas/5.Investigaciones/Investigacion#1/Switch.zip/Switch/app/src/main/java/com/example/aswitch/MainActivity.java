package com.example.aswitch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.os.Bundle;
import android.widget.Toast;
import android.widget.Switch;
import android.view.View;

public class MainActivity extends AppCompatActivity {

 private  Switch switch1,switch2,switch3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        switch1=findViewById(R.id.switch1);
        switch2=findViewById(R.id.switch2);
        switch3=findViewById(R.id.switch3);
    }
    public void data (View v) {
        if (switch1.isChecked())
            Toast.makeText(this, "Datos Moviles Activados", Toast.LENGTH_SHORT).show();

        else
            Toast.makeText(this, "Datos Moviles Desactivados", Toast.LENGTH_SHORT).show();



    }
    public void wifi (View v){

        if (switch2.isChecked())
            Toast.makeText(this, "WI-FI Activados", Toast.LENGTH_SHORT).show();

        else
            Toast.makeText(this, "WI-FI Desactivados", Toast.LENGTH_SHORT).show();

    }


public void onCheckedChanged(View V) {
                if (switch3.isChecked()) {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                } else {
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                }
            }
        }